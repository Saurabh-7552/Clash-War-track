export interface LeaderboardEntry {
  clanName: string;
  playerName: string;
  totalStars: number;
}
