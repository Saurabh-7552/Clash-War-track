export interface PlayerWarResult {
  id?: number;
  clanName: string;
  playerName: string;
  warId: string;
  stars: number;
  createdAt?: string;
}
